import React from 'react'

const Child1 = () => {
  return (
    <div className='bg-green-200 h-full w-full text-3xl flex flex-col '>Child1</div>
  )
}

export default Child1