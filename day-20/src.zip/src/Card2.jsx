import React from 'react'

const Card2 = () => {
  return (
    <div className='p-2 m-2 text-center bg-lime-400 shadow-xl rounded-lg'>
        <h1>Card 2 Heading</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nisi, architecto!</p>
    </div>
  )
}

export default Card2