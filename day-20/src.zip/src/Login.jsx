import React, { useState } from 'react'

const Login = () => {
    const [email,setEmail]=useState("");
    const [password,setPassword]=useState("");
    const [loading,setLoading]=useState(false);
    const handleSubmit=(e)=>{
        e.preventDefault();
        setLoading(true);
        setTimeout(()=>{
            console.log({
            email:email,
            password:password
        });
        setLoading(false);
        alert(`${email} Logged-In`);
    },5000);
    }

  return (
    <div className='w=4/5 h-4/5 bg-white flex rounded shadow-2xl m-10'>
        <div className=''>
        <img src="https://image.freepik.com/free-vector/mobile-login-concept-illustration_114360-83.jpg" alt="" className='h-full' />
        </div>
        <div className='w-1/2 flex flex-col justify-center items-center gap-5'>
            <h1 className='text-2xl font-semibold'>Welocme Back!</h1>
            
            <form onSubmit={handleSubmit}>
            <input type="email" placeholder='Email' className='border my-3' onChange={(e)=>{
                setEmail(e.target.value)
            }}/>
            <br />
            <input type="password" placeholder='Password' className='border my-3' onChange={(p)=>{
                setPassword(p.target.value)
            }}/>
            <br />
            <button type="submit" className='w-20 h-10 bg-green-900 text-white rounded-xl' 
             onClick={(e,p)=>{
                console.log(e);
                console.log(p);
                
             }}
            >{loading?"Logging...":"Login"}</button>
            </form>
        </div>
    </div>
  )
}

export default Login