// // import { useState } from 'react'
// // import './App.css'
// import Home from "./Home.jsx"

// import Home from "./Home";
import { useEffect, useState } from "react";
import Card1 from "./Card1";
import ProductImage1 from "./assets/1.jpeg"
import ProductImage2 from "./assets/2.jpeg"
import ProductImage3 from "./assets/3.jpeg"
import ProductImage4 from "./assets/4.jpeg"
import Child  from "./Child.jsx";
import Login from "./Login.jsx";


// function App() {
//   // const [count, setCount] = useState(0)

//   return (
//     <>
//       {/* <h1>Hello Techno</h1> */}
//       <Home />
//     </>
//   )
// }

// export default App

// export default function App() {
//   return (
//     <h1 style={{backgroundColor:"greenyellow"}}>
//       Hello world!
//     </h1>
//   )
// }

// const data = [
//   {
//     heading : "Card 1",
//     description : "Card 1 Description",
//     classname : "bg-slate-300",
//     image : ProductImage1
//   },
//   {
//     heading : "Card 2",
//     description : "Card 2 Description",
//     classname : "bg-green-300",
//     image : ProductImage2
//   },
//   {
//     heading : "Card 3",
//     description : "Card 3 Description",
//     classname : "bg-red-300",
//     image : ProductImage3
//   },
//   {
//     heading : "Card 4",
//     description : "Card 4 Description",
//     classname : "bg-blue-300",
//     image : ProductImage4
//   },
//   {
//     heading : "Card 5",
//     description : "Card 5 Description",
//     classname : "bg-cyan-300",
//     image : ProductImage2
//   },
//   {
//     heading : "Card 6",
//     description : "Card 6 Description",
//     classname : "bg-purple-300",
//     image : ProductImage3
//   },
//   {
//     heading : "Card 7",
//     description : "Card 7 Description",
//     classname : "bg-orange-300",
//     image : ProductImage4
//   },
//   {
//     heading : "Card 8",
//     description : "Card 8 Description",
//     classname : "bg-sky-300",
//     image : ProductImage1
//   },
// ]

export default function App() {

  // hooks
  // useState: the values of a variable is changed internally, but not in the html or on the screen
  // useEffect: useState rerenders the file whenever it is used to change a value, this func fetch renders again also, thus to eliminate this, it is used

  // let c=0;

  // const [c , setc] = useState(0); //using [state, set(stateName)]
  // const [productId , setProductId] = useState(1);

    // const fetchData =()=>{
  //   console.log("Hello Techno from fetch Data Function");
    
  // }

  // const fetchData= async (id)=>{
  //   try{
  //   const response=await fetch(`https://fakestoreapi.com/products/${id}`)
  //   const data=await Response.json();
  //   console.log(data);
  //   }catch(error){
  //     console.log(error);
      
  //   }
  // }
  // useEffect(()=>{
  //   fetchData(productId)
  //   // console.log(count);
  //   // setCount(prev=>prev+1)
    
  // },[productId])
  // use effect can also give error to avoid such scenario we make it dependent by passing dependency array
  //sirf ek bar he chalana ho toh empty array pass kerdo 
  //otherwise kes pe dependent bna ho toh usko array me pass kerdo



  return (
    <div className="w-full h-full flex justify-center text-center">
      
      
      {/* <Home/> */}
      {/* <Card1 image={vec1} heading="C1 heading" description="This is a C1 description" classname="bg-emerald-500"/>
      <Card1 image={vec2} heading="C1 heading" description="This is a C1 description" classname="bg-red-600"/>
      <Card1 image={vec3} heading="C1 heading" description="This is a C1 description" classname="bg-amber-400"/>
      <Card1 image={vec4} heading="C1 heading" description="This is a C1 description" classname="bg-cyan-500"/> */}

     {/* { data.map((item,i)=>{
        return(
          <Card1 heading={item.heading} classname={item.classname} description={item.description} image={item.image}/>
        )
      })
      } */}

      {/* <p className="text-4xl font-medium text-white">The value of count is : {c}</p>
<Child c={c} setc={setc}/>

      <button className="bg-slate-200 p-2 m-4 active:bg-red-600 active:text-white rounded-lg" onClick={()=>{
        setc(c-1);
        console.log(c);
        
      }}>Dec Count(-)</button>

      <button className="bg-slate-200 p-2 m-4 active:bg-lime-600 active:text-white rounded-lg" onClick={()=>{
        setc(c+1);
        console.log(c);
        
      }}>Inc Count(+)</button> */}

      <Login/>

      {/* <button className='border-2 p-2 px-4 border-gray-200 active:bg-gray-700 active:text-gray-200
      ' onClick={()=>{setCount(count+1)}}>+Count</button>
      <p className='"text-2xl'>The value of Count is:{count}</p>
      <p className='"text-2xl'>The value of ProductId is:{productId}</p>
     
      <button className='border-2 p-2 px-4 border-gray-200 active:bg-gray-700 active:text-gray-200
      ' onClick={()=>{setProductId(productId+1)}}>+ProductId</button> */}

        {/* <Child/> */}


    </div>
  )
}