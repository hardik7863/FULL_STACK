import React from 'react'
import Child1 from './Child1';

const Child = ({c,setc}) => {
  return (
    <div className='h-full w-full text-2xl bg-emerald-600 p-5 m-5 rounded-xl text-white justify-center items-center'>
        Child 1

        <Child1/>

        {/* <p className='text-2xl'>The value of count : {c}</p>
        <button className="bg-blue-950 p-2 m-4 active:bg-red-600 active:text-white rounded-lg" onClick={()=>{
        setc(c-1);
        console.log(c);
        
      }}>Dec Count(-)</button>

      <button className="bg-blue-950 p-2 m-4 active:bg-lime-600 active:text-white rounded-lg" onClick={()=>{
        setc(c+1);
        console.log(c);
        
      }}>Inc Count(+)</button> */}
        </div>
  )
}

export default Child;